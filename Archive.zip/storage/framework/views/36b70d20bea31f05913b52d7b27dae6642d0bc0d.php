 <form method="POST" action="add">

 <div class="form-group">

                                            <label>Name</label>
                                            <input ng-model="name" name="name" class="form-control">
                                            <p class="help-block">The name of city</p>
                                        </div>
        <div class="form-group">
                                            <label>CODE</label>
                                            <input  ng-model="code" class="form-control">
                                            <p class="help-block">The code of city</p>
                                        </div>  

                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

<input type="submit" value="add">
                                        </form>