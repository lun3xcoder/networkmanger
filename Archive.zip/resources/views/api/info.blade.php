<?php 

$info = array('d'=>$info_d,'c'=>$info_c,'cu'=>$info_cu);
echo json_encode($info);
