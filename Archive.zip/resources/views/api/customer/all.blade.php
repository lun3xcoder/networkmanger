<?php 

echo json_encode($customer);