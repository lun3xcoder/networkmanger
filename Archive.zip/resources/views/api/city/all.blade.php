<?php 

echo json_encode($city);