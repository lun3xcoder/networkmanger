<?php 

echo "ok";