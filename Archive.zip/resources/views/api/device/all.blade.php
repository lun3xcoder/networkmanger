<?php 

echo json_encode($device);
