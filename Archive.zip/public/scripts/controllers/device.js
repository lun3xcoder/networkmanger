'use strict';
/**
 * @ngdoc function
 * @name NetworkManger.controller:DeviceCtrl
 * @description
 * # DeviceCtrl
 * Controller of the NetworkManger
 * Copyright © 2017 Lun3x.com
 * Coded By : Majid Abdulalrazzaq
 * Email : info@lun3x.com , majidcoderlun3x@gmail.com
 */


 
angular.module('sbAdminApp')
  .controller('DeviceCtrl', function(toaster,$scope,$position,$http) {




$scope.city = function() 
{
    $http.get('api/city/all').success(function (data) {
               
                 $scope.cities = data;
                                  $scope.cityes = '0';


            });
}

$scope.customer = function() 
{
    $http.get('api/customer/all').success(function (data) {
               
                 $scope.customeres = data;
                 $scope.customer_d = '0';
            });
}


$scope.displayData = function() 
{
    $http.get('api/device/all').success(function (data) {
               
                 $scope.devices = data;
            });


}



    $scope.open = function() 
{


      $scope.name = null;
      $scope.username = null;
      $scope.ip = null;
      $scope.password = null;
      document.getElementById("UPDATE").style.display='none';
      document.getElementById("ADD").style.display='';
      $("#update_header").hide();
      $("#add_header").show();

      $("#add_modal").modal("show");
  
}




    $scope.insertData = function() 
{

   if(!$scope.name ){
toaster.pop('error', "Error", 'Name Is required', null, 'trustedHtml');

return 0;
 }


var test = $('meta[name="csrf-token"]').attr('content');

        $http.post(
            "api/device/add",
            {
                'name':$scope.name,
                'ip':$scope.ip,
                'username':$scope.username,
                'password':$scope.password,
                'customer_id':$scope.customer_d,
                'city_id':$scope.cityes
            }).success(function (data) {
toaster.pop('success', "Success Add", 'Successfully Add', null, 'trustedHtml');

                $("#add_modal").modal("hide");
                $scope.displayData()
            });
        
}







$scope.deleteData    = function(id ) 
{
if (confirm("Are you sure !!!? ")) {
     $http.post(
            "api/device/delete",
            {
                
                'id':id,
               
            }).success(function (data) {
toaster.pop('success', "Success Delete", 'Successfully Delete', null, 'trustedHtml');

                  $scope.displayData()
            });

}else{
      return false;

}
             
             
}

$scope.getInfo = function(id ) 
{


     $http.post(
            "api/device/view",
            {
                
                'id':id,
               
            }).success(function (data) {

                $scope.id = data.id;
                $scope.name = data.name;
                $scope.username = data.username;
                $scope.ip = data.ip;
                $scope.password = data.password;
                $scope.customer_d = data.customer_id;
                $scope.cityes = data.city_id;

                document.getElementById("ADD").style.display='none';
                document.getElementById("UPDATE").style.display='';  

                $("#update_header").show();
                $("#add_header").hide();
                $("#add_modal").modal("show");

                  
            });        
             
}


    $scope.updateData = function(id) 
{
var groups = $('#show_group').val();
   if(!$scope.name ){
toaster.pop('error', "Error", 'Name Is required', null, 'trustedHtml');

return 0;
 }


        $http.post(
            "api/device/update",
            {
                'id':id,
                'name':$scope.name
            }).success(function (data) {
toaster.pop('success', "Success Update", 'Successfully Update', null, 'trustedHtml');

                $("#add_modal").modal("hide");
                $scope.displayData()
            });
        
}






  });



  