'use strict';
/**
 * @ngdoc function
 * @name NetworkManger.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the NetworkManger
 */
angular.module('sbAdminApp')
  .controller('MainCtrl', function(toaster,$scope,$position,$http) {


  	$scope.displayData = function() 
{
    $http.get('api/info').success(function (data) {
               
                 $scope.infos = data;
            });


}
  });
