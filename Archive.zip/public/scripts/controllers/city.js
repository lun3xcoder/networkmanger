'use strict';
/**
 * @ngdoc function
 * @name NetworkManger.controller:CityCtrl
 * @description
 * # CityCtrl
 * Controller of the NetworkManger
 * Copyright © 2017 Lun3x.com
 * Coded By : Majid Abdulalrazzaq
 * Email : info@lun3x.com , majidcoderlun3x@gmail.com
 */

 
angular.module('sbAdminApp')
  .controller('CityCtrl', function(toaster,$scope,$position,$http) {






$scope.displayData = function() 
{
    $http.get('api/city/all').success(function (data) {
               
                 $scope.cities = data;
            });
}



    $scope.open = function() 
{


      $scope.name = null;
      $scope.code = null;
      document.getElementById("UPDATE").style.display='none';
      document.getElementById("ADD").style.display='';
      $("#update_header").hide();
      $("#add_header").show();

      $("#add_modal").modal("show");
  
}




    $scope.insertData = function() 
{

   if(!$scope.name ){
toaster.pop('error', "Error", 'Name Is required', null, 'trustedHtml');

return 0;
 }
  if(!$scope.code ){
toaster.pop('error', "Error", 'Code Is required', null, 'trustedHtml');

return 0;
 }

var test = $('meta[name="csrf-token"]').attr('content');

        $http.post(
            "api/city/add",
            {
                'name':$scope.name,
                'code':$scope.code
            },
                {
        headers:{'X-CSRF-TOKEN': test}
    }
            ).success(function (data) {
toaster.pop('success', "Success Add", 'Successfully Add', null, 'trustedHtml');

                $("#add_modal").modal("hide");
                $scope.displayData()
            });
        
}







$scope.deleteData    = function(id ) 
{
if (confirm("Are you sure !!!? ")) {
     $http.post(
            "api/city/delete",
            {
                
                'id':id,
               
            }).success(function (data) {
toaster.pop('success', "Success Delete", 'Successfully Delete', null, 'trustedHtml');

                  $scope.displayData()
            });

}else{
      return false;

}
             
             
}

$scope.getInfo = function(id ) 
{


     $http.post(
            "api/city/view",
            {
                
                'id':id,
               
            }).success(function (data) {
                $scope.id = data.id;
                $scope.name = data.name;
                $scope.code =  data.code;
                document.getElementById("ADD").style.display='none';
                document.getElementById("UPDATE").style.display='';  

                $("#update_header").show();
                $("#add_header").hide();
                $("#add_modal").modal("show");

                  
            });        
             
}


    $scope.updateData = function(id) 
{
var groups = $('#show_group').val();
   if(!$scope.name ){
toaster.pop('error', "Error", 'Name Is required', null, 'trustedHtml');

return 0;
 }
  if(!$scope.code ){
toaster.pop('error', "Error", 'Ip Is required', null, 'trustedHtml');

return 0;
 }

        $http.post(
            "api/city/update",
            {
                'id':id,
                'name':$scope.name,
                'code':$scope.code
            }).success(function (data) {
toaster.pop('success', "Success Update", 'Successfully Update', null, 'trustedHtml');

                $("#add_modal").modal("hide");
                $scope.displayData()
            });
        
}






  });



  