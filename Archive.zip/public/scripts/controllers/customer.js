'use strict';
/**
 * @ngdoc function
 * @name NetworkManger.controller:CustomerCtrl
 * @description
 * # CustomerCtrl
 * Controller of the NetworkManger
 * Copyright © 2017 Lun3x.com
 * Coded By : Majid Abdulalrazzaq
 * Email : info@lun3x.com , majidcoderlun3x@gmail.com
 */

 
angular.module('sbAdminApp')
  .controller('CustomerCtrl', function(toaster,$scope,$position,$http) {






$scope.displayData = function() 
{
    $http.get('api/customer/all').success(function (data) {
               
                 $scope.customeres = data;
            });
}



    $scope.open = function() 
{


      $scope.name = null;
      document.getElementById("UPDATE").style.display='none';
      document.getElementById("ADD").style.display='';
      $("#update_header").hide();
      $("#add_header").show();

      $("#add_modal").modal("show");
  
}




    $scope.insertData = function() 
{

   if(!$scope.name ){
toaster.pop('error', "Error", 'Name Is required', null, 'trustedHtml');

return 0;
 }


var test = $('meta[name="csrf-token"]').attr('content');

        $http.post(
            "api/customer/add",
            {
                'name':$scope.name
            }).success(function (data) {
toaster.pop('success', "Success Add", 'Successfully Add', null, 'trustedHtml');

                $("#add_modal").modal("hide");
                $scope.displayData()
            });
        
}







$scope.deleteData    = function(id ) 
{
if (confirm("Are you sure !!!? ")) {
     $http.post(
            "api/customer/delete",
            {
                
                'id':id,
               
            }).success(function (data) {
toaster.pop('success', "Success Delete", 'Successfully Delete', null, 'trustedHtml');

                  $scope.displayData()
            });

}else{
      return false;

}
             
             
}

$scope.getInfo = function(id ) 
{


     $http.post(
            "api/customer/view",
            {
                
                'id':id,
               
            }).success(function (data) {
                $scope.id = data.id;
                $scope.name = data.name;
                document.getElementById("ADD").style.display='none';
                document.getElementById("UPDATE").style.display='';  

                $("#update_header").show();
                $("#add_header").hide();
                $("#add_modal").modal("show");

                  
            });        
             
}


    $scope.updateData = function(id) 
{
var groups = $('#show_group').val();
   if(!$scope.name ){
toaster.pop('error', "Error", 'Name Is required', null, 'trustedHtml');

return 0;
 }


        $http.post(
            "api/customer/update",
            {
                'id':id,
                'name':$scope.name
            }).success(function (data) {
toaster.pop('success', "Success Update", 'Successfully Update', null, 'trustedHtml');

                $("#add_modal").modal("hide");
                $scope.displayData()
            });
        
}






  });



  